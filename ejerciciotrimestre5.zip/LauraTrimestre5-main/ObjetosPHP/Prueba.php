<?php
printf(phpinfo());
?>