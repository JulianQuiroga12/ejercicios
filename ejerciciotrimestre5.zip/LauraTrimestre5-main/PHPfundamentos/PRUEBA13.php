<?php
echo "Codigo de php para generar numeros del 1-5"."\n";
$i = 1;
do{
    echo "El valor de i es" . $i ."\n";
    $i++;
}
While($i <= 5)
;
?>