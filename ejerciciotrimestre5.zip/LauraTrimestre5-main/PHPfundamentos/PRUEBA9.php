<?php
$arreglo = [
"Nombre" => "Pedro",
"Apellido" => "Perez",
];
echo "Buenos días". $arreglo["Nombre"] . " " .
$arreglo["Apellido"] ;
?>