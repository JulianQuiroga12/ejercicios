<?php
// este es comentario de una línea
# este es otro comentario de una línea.
echo "hola mundo" ;
?>