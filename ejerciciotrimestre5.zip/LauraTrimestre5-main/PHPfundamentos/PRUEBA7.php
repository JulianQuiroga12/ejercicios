<?php
echo "Ejemplo de una constante \n";
define( "SENA", "Servicio nacional de aprendizaje");
echo SENA;
?>