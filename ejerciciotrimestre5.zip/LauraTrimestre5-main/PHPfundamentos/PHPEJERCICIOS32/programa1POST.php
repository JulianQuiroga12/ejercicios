<html>
<body>
    <?php
    echo "Hola".$_POST["nombre"]." ".$_POST["apellido"]."<br>";
    ?>
</body>
</html>