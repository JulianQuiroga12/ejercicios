<html>
<body>
    <?php
    echo "Hola".$_GET["nombre"]." ".$_GET["apellido"]."<br>";
    ?>
</body>
</html>