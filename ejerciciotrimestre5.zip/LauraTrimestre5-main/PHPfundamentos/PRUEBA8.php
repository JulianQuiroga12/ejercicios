<?php
$nombre = "Pedro";
$apellido = "Perez";
echo "Buenos dias" . " ". $nombre . " " . $apellido ;
?>