<html>
<body>
<?php
// El código php va aquí.
?>
</body>
</html>