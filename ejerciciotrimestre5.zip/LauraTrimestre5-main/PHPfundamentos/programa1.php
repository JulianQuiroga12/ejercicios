<html>
    <body>
        <?php">
        echo "hola".$_POST["nombre"]."".$_POST["apellido"]."<br>";
    ?>
    </body>
</html>