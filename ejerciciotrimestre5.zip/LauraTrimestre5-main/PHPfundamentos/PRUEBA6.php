<?php
// Ejemplos de declaración de variables.
$nombre = "Pedro"; // variable tipo texto;
$apellido = "Perez"; // variable tipo texto;
$edad = 45; // variable numérica ;
echo "El señor ". $nombre . " " . $apellido . " tiene una
edad de ". $edad . " años. " ;
?>