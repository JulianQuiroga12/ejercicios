// prueba.php
<php
printf( phpinfo() ) ;
?>