<?php
include_once ″<nombre_biblioteca.php>″ ;
?>