<?php
/*
este es comentario abarca varias líneas.
Los comentarios son útiles para documentar los
programas.
*/
echo "hola mundo" ;
?>