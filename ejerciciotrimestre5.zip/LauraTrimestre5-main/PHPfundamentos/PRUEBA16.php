<?php
$arreglo = ["Jacinto", "Jose", "pepita", "mendieta"] ;
$j = 0;
foreach($arreglo as $elemento)
{
    echo "$j: $elemento \n";
}
?>