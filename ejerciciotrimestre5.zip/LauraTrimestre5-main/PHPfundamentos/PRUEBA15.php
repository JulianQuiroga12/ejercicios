<?php
echo "Ejemplo del uso de comando swithc en php \n";
$i = 5;
switch($i)
{
    case 1:
        echo"uno";
        break;
    case 2:
        echo"Dos";
        break;
    case 3:
        echo"Tres";
        break;
    case 4:
        echo"Cuatro";
        break;
    default:
    echo "solo me programaron entre uno y cuatro \n";
};
?>