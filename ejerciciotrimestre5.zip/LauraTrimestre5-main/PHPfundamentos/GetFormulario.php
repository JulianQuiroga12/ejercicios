<html>
    <body>
        <form action="programa1.php">
            Nombre:<input type="text" name="nombre"><br>
            Apellido:<input type="text" name="apellido"><br>
            input type=submit value="Enviar">
        </form>
    </body>
</html>