<?php
$arreglo = [
"Primer_Nombre" => "Pedro",
"Segundo_Nombre" => "Pablo",
"Primer_Apellido" => "Perez",
"Segundo_Apellido" => "Pereira"
];
foreach($arreglo as $llave => $elemento)
{
echo "$llave: $elemento \n";
};
?>