<html>
    <body>
        <p>Ejemplo de estructura condicional sencilla</p><br>
        <?php
        echo "Codigo PHP de un condicional sencillo <br>";
        $a = 8;
        $b = 3;
        if($a < $b ){
            echo "a es menor que b";
        } else {
            echo "a es mayor que b";
        };
        ?>
    </body>
</html>