<?php
echo "Ejemplo del uso del ciclo for en php \n";
for($i=1; $i<=7; $i++)
{
    echo "Linea " . $i ."\n";
};
?>